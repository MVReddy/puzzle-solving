public class PhoneList{

     public static void main(String []args){
        System.out.println(phonelist(a));
        System.out.println(phonelist(b));
     }
     
    public static Integer[] a = { 911,
      97625999,
      91125426
    };
    // good list
    public static Integer[] b = {113,
      12340,
      123440,
      12345,
      98346
    };

    public static String phonelist(Integer[] a/*list <~10000*/) {
      boolean brk = false;
      dance: for (Integer i = 0; i < a.length - 1; i++) {
        for (Integer j = 1; j < a.length; j++) {
          // avoid compare with the same index in the array
          // we use regex here, still optimal so such solution in terms of speed
          if (!i.equals(j)) brk = String.valueOf(a[j]).matches("^" + a[i] + "\\d*");
          // break everything if we prefix matched
          if (brk) break dance;
        }
      }
      return (brk) ? "NO" : "YES";
    }
}
